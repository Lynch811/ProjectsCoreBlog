# 403 Forbidden

A Pen created on CodePen.io. Original URL: [https://codepen.io/Chesswithsean/pen/ZMwagQ](https://codepen.io/Chesswithsean/pen/ZMwagQ).

